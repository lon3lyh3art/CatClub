КОТОКЛУБ — Android-проект
==========================

Это Android-оболочка для игры КотоКлуб Deluxe. Игра запускается локально,
интернет для игры не нужен, очки сохраняются в хранилище браузера WebView.

КАК ПОЛУЧИТЬ APK (через Android Studio)
1. Установи Android Studio с официального сайта:
   https://developer.android.com/studio
2. Распакуй архив KotoClubAndroid.zip.
3. В Android Studio выбери Open и укажи папку KotoClubAndroid.
4. Дождись Gradle Sync. Если программа попросит установить Android SDK
   Platform 35, согласись.
5. В меню выбери Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. После сборки нажми Locate. Обычно APK появится здесь:
   app/build/outputs/apk/debug/app-debug.apk
7. Перенеси app-debug.apk на телефон и открой его для установки.
   Возможно, Android попросит разрешить установку из этого источника.

ТЕХНИЧЕСКИ
- Название приложения: КотоКлуб
- Package: ru.kotoclub.game
- Минимальная версия: Android 6.0 (API 23)
- Игра и ресурсы встроены в приложение; подключение к интернету не требуется.

ВАЖНО
В этой среде нет Android SDK/Gradle, поэтому здесь создан проект для сборки,
а не готовый APK. Сам APK получится после шага Build APK(s) в Android Studio.
