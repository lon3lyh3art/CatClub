/* KotoClub 3.5 — dependency-free WebGL 1.0 scene engine.
 * Perspective camera, depth buffer, vertex lighting, mesh transforms, continuous render loop.
 * No CDN, no external runtime; runs inside Android WebView offline. */
(()=>{
'use strict';
const $=s=>document.querySelector(s);
const track=$('#goldrun .car-track'); if(!track)return;
const canvas=document.createElement('canvas'); canvas.id='koto3d-canvas'; canvas.setAttribute('aria-label','3D гоночная трасса');
Object.assign(canvas.style,{position:'absolute',inset:'0',width:'100%',height:'100%',display:'block',touchAction:'pan-y'});
track.style.position='relative'; track.style.overflow='hidden'; track.appendChild(canvas);
const gl=canvas.getContext('webgl',{alpha:false,antialias:true,powerPreference:'high-performance'});
if(!gl){canvas.style.display='none';const note=document.createElement('div');note.textContent='3D-режим недоступен в этом WebView';note.style.cssText='padding:20px;color:white';track.appendChild(note);return;}
const vs=`attribute vec3 aPos;attribute vec3 aNormal;uniform mat4 uMVP;uniform mat4 uModel;varying float vLight;varying float vFog;void main(){vec4 world=uModel*vec4(aPos,1.0);gl_Position=uMVP*vec4(aPos,1.0);vec3 n=normalize(mat3(uModel)*aNormal);vec3 light=normalize(vec3(-.45,.85,.4));vLight=.38+.62*max(dot(n,light),0.0);vFog=clamp((-world.z-2.0)/27.0,0.0,.72);}`;
const fs=`precision mediump float;uniform vec3 uColor;varying float vLight;varying float vFog;void main(){vec3 fog=vec3(.13,.19,.31);vec3 c=uColor*vLight;c=mix(c,fog,vFog);gl_FragColor=vec4(c,1.0);}`;
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();gl.attachShader(prog,shader(gl.VERTEX_SHADER,vs));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(prog));gl.useProgram(prog);
const loc={p:gl.getAttribLocation(prog,'aPos'),n:gl.getAttribLocation(prog,'aNormal'),mvp:gl.getUniformLocation(prog,'uMVP'),model:gl.getUniformLocation(prog,'uModel'),color:gl.getUniformLocation(prog,'uColor')};
function meshData(pos,norm,idx){const m={count:idx.length};m.p=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,m.p);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(pos),gl.STATIC_DRAW);m.n=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,m.n);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(norm),gl.STATIC_DRAW);m.i=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(idx),gl.STATIC_DRAW);return m;}
function boxMesh(){let p=[],n=[],idx=[];const faces=[[[0,0,1],[[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]]],[[0,0,-1],[[.5,-.5,-.5],[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5]]],[[1,0,0],[[.5,-.5,.5],[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5]]],[[-1,0,0],[[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]]],[[0,1,0],[[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5],[-.5,.5,-.5]]],[[0,-1,0],[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]]]];faces.forEach((f,k)=>{const b=p.length/3;f[1].forEach(v=>{p.push(...v);n.push(...f[0])});idx.push(b,b+1,b+2,b,b+2,b+3)});return meshData(p,n,idx)}
function sphereMesh(){let p=[],n=[],idx=[],rings=10,segs=14;for(let r=0;r<=rings;r++){let v=r/rings,phi=v*Math.PI;for(let s=0;s<=segs;s++){let u=s/segs,theta=u*Math.PI*2,x=Math.sin(phi)*Math.cos(theta),y=Math.cos(phi),z=Math.sin(phi)*Math.sin(theta);p.push(x*.5,y*.5,z*.5);n.push(x,y,z)}}for(let r=0;r<rings;r++)for(let s=0;s<segs;s++){let a=r*(segs+1)+s,b=a+segs+1;idx.push(a,b,a+1,b,b+1,a+1)}return meshData(p,n,idx)}
const box=boxMesh(),sphere=sphereMesh();
function I(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}
function mul(a,b){let o=new Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o}
function translate(x,y,z){let m=I();m[12]=x;m[13]=y;m[14]=z;return m}
function scale(x,y,z){let m=I();m[0]=x;m[5]=y;m[10]=z;return m}
function rotateY(a){let m=I(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[2]=-s;m[8]=s;m[10]=c;return m}
function perspective(fovy,aspect,near,far){let f=1/Math.tan(fovy/2),nf=1/(near-far),m=new Array(16).fill(0);m[0]=f/aspect;m[5]=f;m[10]=(far+near)*nf;m[11]=-1;m[14]=2*far*near*nf;return m}
function lookAt(eye,center,up){let z=norm([eye[0]-center[0],eye[1]-center[1],eye[2]-center[2]]),x=norm(cross(up,z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]}function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}function norm(a){let l=Math.hypot(...a)||1;return a.map(v=>v/l)}
function draw(m,model,color){gl.bindBuffer(gl.ARRAY_BUFFER,m.p);gl.enableVertexAttribArray(loc.p);gl.vertexAttribPointer(loc.p,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,m.n);gl.enableVertexAttribArray(loc.n);gl.vertexAttribPointer(loc.n,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.uniformMatrix4fv(loc.model,false,new Float32Array(model));gl.uniformMatrix4fv(loc.mvp,false,new Float32Array(mul(vp,model)));gl.uniform3fv(loc.color,color);gl.drawElements(gl.TRIANGLES,m.count,gl.UNSIGNED_SHORT,0)}
let vp=I(),last=0,alive=true,elapsed=0;
const C={road:[.11,.15,.23],edge:[.93,.62,.24],stripe:[.84,.91,1],red:[.94,.18,.25],blue:[.14,.72,.96],black:[.045,.06,.09],glass:[.18,.72,.88],gold:[1,.67,.08],barrier:[1,.28,.15],grass:[.10,.31,.27],white:[.9,.94,1]};
function car(x,z,body){draw(box,mul(translate(x,.25,z),scale(.92,.36,1.45)),body);draw(box,mul(translate(x,.52,z-.12),scale(.56,.34,.62)),C.glass);for(let wx of [-.38,.38])for(let wz of [-.45,.45])draw(sphere,mul(translate(x+wx,.12,z+wz),scale(.23,.23,.23)),C.black);draw(box,mul(translate(x,.28,z-.76),scale(.62,.1,.12)),C.white)}
function resize(){let r=canvas.getBoundingClientRect(),d=Math.min(window.devicePixelRatio||1,1.7);let w=Math.max(1,Math.round(r.width*d)),h=Math.max(1,Math.round(r.height*d));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)} }
function render(t){if(!alive)return;if(t-last<15)return;last=t;elapsed=t/1000;resize();gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(.09,.14,.24,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);let aspect=canvas.width/canvas.height;vp=mul(perspective(48*Math.PI/180,aspect,.1,90),lookAt([0,6.2,9.5],[0,0,-5],[0,1,0]));
// world floor and asphalt roadway
 draw(box,mul(translate(0,-.42,-8),scale(34,.3,44)),C.grass);draw(box,mul(translate(0,-.20,-8),scale(6.6,.25,34)),C.road);
 draw(box,mul(translate(-3.18,-.04,-8),scale(.16,.08,34)),C.edge);draw(box,mul(translate(3.18,-.04,-8),scale(.16,.08,34)),C.edge);
 for(let z=-24;z<5;z+=3.4){draw(box,mul(translate(-1.08,-.055,z+((elapsed*8)%3.4)),scale(.055,.035,1.45)),C.stripe);draw(box,mul(translate(1.08,-.055,z+((elapsed*8)%3.4)),scale(.055,.035,1.45)),C.stripe)}
 // low-poly roadside lights and scenery
 for(let z=-22;z<4;z+=5){for(let side of [-1,1]){draw(box,mul(translate(side*4.4,.6,z+((elapsed*4)%5)),scale(.12,1.2,.12)),C.edge);draw(sphere,mul(translate(side*4.4,1.25,z+((elapsed*4)%5)),scale(.35,.35,.35)),[.15,.65,1])}}
 const duel=typeof carTwo!=='undefined'&&carTwo;const lanes=duel&&typeof carPlayers!=='undefined'?[carPlayers[0],carPlayers[1]]:[{lane:typeof carLane!=='undefined'?carLane:1,obstacles:window.carObstacles||[]}];
 lanes.forEach((p,i)=>{const x=(p.lane-1)*2.05+(duel?(i===0?-.22:.22):0);car(x,1.1,duel?(i===0?C.blue:C.red):C.red);(p.obstacles||[]).forEach(o=>{let oz=-Math.max(0,o.z||0)*1.6-.3,ox=(o.lane-1)*2.05;if(o.type==='coin'){draw(sphere,mul(translate(ox,.65,oz),mul(rotateY(elapsed*3),scale(.52,.52,.16))),C.gold);draw(sphere,mul(translate(ox,.65,oz),scale(.22,.22,.20)),[1,.9,.35])}else{draw(box,mul(translate(ox,.35,oz),scale(.86,.72,.65)),C.barrier);draw(box,mul(translate(ox,.39,oz),mul(rotateY(-.15),scale(.91,.12,.68))),C.gold)}})});
 // subtle floating dust glints
 for(let i=0;i<8;i++){let z=-((elapsed*4+i*3)%24),x=Math.sin(i*8.1+elapsed*.3)*4.2;draw(sphere,mul(translate(x,1.3+Math.sin(elapsed+i)*.25,z),scale(.045,.045,.045)),[.3,.75,1])}
}
// Keep old lane DOM available to game rules, but render the active scene in WebGL.
const style=document.createElement('style');style.textContent='#goldrun .car-track{height:clamp(340px,62vh,540px);min-height:340px;background:#17233d!important;border-radius:18px!important}#goldrun .car-track>.car-lanes{display:none!important}#goldrun #carDuel .car-track{height:300px}#koto3d-canvas{border-radius:14px}';document.head.appendChild(style);
const sceneControl=window.Koto3DRuntime.register('race',canvas,render);
window.Koto3DEngine={version:'0.3.0-webgl',renderer:'WebGL 1.0',externalDependencies:0,dispose(){alive=false;sceneControl.dispose();canvas.remove()}};
})();
