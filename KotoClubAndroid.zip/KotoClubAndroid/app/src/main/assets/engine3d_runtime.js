/* KotoClub 3.11 — shared WebGL scene lifecycle, pause/resume and FPS diagnostics. */
(()=>{'use strict';
const scenes=new Map();let globallyPaused=false;
function register(name,canvas,drawFrame){
 const root=canvas.closest('.screen');let raf=0,disposed=false,lastFrame=0,frames=0,fps=0,windowStart=0;
 const active=()=>!disposed&&!globallyPaused&&!document.hidden&&!!root&&root.classList.contains('active')&&canvas.isConnected;
 function stop(){if(raf){cancelAnimationFrame(raf);raf=0}}
 function frame(now){raf=0;if(!active())return;raf=requestAnimationFrame(frame);
  if(!windowStart)windowStart=now;frames++;
  if(now-windowStart>=1000){fps=Math.round(frames*1000/(now-windowStart));frames=0;windowStart=now;}
  const delta=lastFrame?Math.min(50,now-lastFrame):16.67;lastFrame=now;
  try{drawFrame(now,delta)}catch(err){console.error('[Koto3D:'+name+'] frame failed',err);stop();canvas.dataset.sceneError='render';}
 }
 function sync(){if(active()){if(!raf)raf=requestAnimationFrame(frame)}else{stop();lastFrame=0;frames=0;windowStart=0}}
 const observer=root?new MutationObserver(sync):null;if(observer)observer.observe(root,{attributes:true,attributeFilter:['class']});
 const onVisibility=()=>sync();document.addEventListener('visibilitychange',onVisibility);window.addEventListener('resize',sync,{passive:true});
 const record={name,canvas,get active(){return active()},get fps(){return fps},sync,dispose(){if(disposed)return;disposed=true;stop();if(observer)observer.disconnect();document.removeEventListener('visibilitychange',onVisibility);window.removeEventListener('resize',sync);scenes.delete(name)}};
 scenes.set(name,record);sync();return record;
}
window.Koto3DRuntime={version:'1.1.0',register,getStats(){return Array.from(scenes.values()).map(s=>({scene:s.name,active:s.active,fps:s.fps}))},pauseAll(){globallyPaused=true;for(const s of scenes.values())s.sync()},resumeAll(){globallyPaused=false;for(const s of scenes.values())s.sync()},isPaused(){return globallyPaused}};
})();
