const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync(__dirname + '/app/src/main/assets/index.html', 'utf8');
const start = html.indexOf('function poolStep(scale){');
const end = html.indexOf('// КОТО-ЗМЕЙКА.', start);
if (start < 0 || end < 0) throw new Error('poolStep not found');
const fn = html.slice(start, end).replace(/\s*function poolPhysics\([\s\S]*?\n}\n(?=function poolStep)/, '');
function run(balls) {
  const labels = {poolPotted:{textContent:'0'}};
  const context = {poolBalls: balls, poolPotted: 0, POCKETS:[[20,20],[360,15],[700,20],[20,380],[360,385],[700,380]], $: id => labels[id] || (labels[id] = {textContent:''})};
  vm.createContext(context); vm.runInContext(fn, context); context.poolStep(1); return context;
}
let c = run([
 {x:100,y:200,vx:2,vy:0,r:13,color:'#fff',cue:true,spinX:0,spinZ:0},
 {x:125,y:200,vx:0,vy:0,r:13,color:'#f00',cue:false,spinX:0,spinZ:0}
]);
if (!(c.poolBalls[0].vx < 0.2 && c.poolBalls[1].vx > 1.5)) throw new Error('Head-on collision did not transfer momentum');
if (Math.hypot(c.poolBalls[1].x-c.poolBalls[0].x,c.poolBalls[1].y-c.poolBalls[0].y) < 25.9) throw new Error('Overlap correction failed');
c = run([{x:24,y:20,vx:-1,vy:0,r:13,color:'#f00',cue:false,spinX:0,spinZ:0}]);
if (c.poolBalls.length !== 0 || c.poolPotted !== 1) throw new Error('Pocket capture failed');
console.log('Billiards physics tests passed: collision impulse, overlap correction, pocket capture.');
