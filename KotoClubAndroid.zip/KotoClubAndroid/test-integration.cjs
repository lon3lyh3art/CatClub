const fs=require('fs'),path=require('path'),assert=require('assert');
const base=path.join(__dirname,'app/src/main/assets');
const html=fs.readFileSync(path.join(base,'index.html'),'utf8');
const srcs=[...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)].map(m=>m[1]);
for(const src of srcs){assert(fs.existsSync(path.join(base,src)),`Missing script asset: ${src}`)}
for(const name of ['engine3d_runtime.js','engine3d_physics.js','engine3d.js','engine3d_billiards.js','engine3d_platformer.js'])assert(srcs.includes(name),`Engine script not included: ${name}`);
assert(html.includes('id="goldrun"')&&html.includes('id="billiards"')&&html.includes('id="platformer"'),'Expected core game screens missing');
for(const f of ['engine3d_runtime.js','engine3d_physics.js','engine3d.js','engine3d_billiards.js','engine3d_platformer.js']){const code=fs.readFileSync(path.join(base,f),'utf8');assert(code.length>500,`Suspiciously small engine file: ${f}`)}
console.log(`Integration asset checks passed: ${srcs.length} script references resolve; shared runtime and three WebGL scenes are included.`);
