const fs=require('fs'),vm=require('vm'),assert=require('assert');
const context={window:{}};vm.runInNewContext(fs.readFileSync(__dirname+'/app/src/main/assets/engine3d_physics.js','utf8'),context);
const P=context.window.Koto3DPhysics,{Vec3,Body,World}=P;
assert.equal(P.version,'0.1.0');
let w=new World({gravity:new Vec3(0,0,0)}),a=w.add(new Body({x:-.4,shape:'sphere',radius:.5,mass:1,velocity:new Vec3(1,0,0)})),b=w.add(new Body({x:.4,shape:'sphere',radius:.5,mass:1,velocity:new Vec3(-1,0,0)}));
w.step(1/60);assert(w.stats.collisions>0,'sphere collision should be detected');assert(a.position.x < b.position.x,'penetration correction should separate spheres');
let floor=new Body({shape:'box',mass:0,position:new Vec3(0,0,0),halfExtents:new Vec3(2,.5,2)}),ball=new Body({shape:'sphere',radius:.5,position:new Vec3(0,.8,0),velocity:new Vec3(0,-1,0),mass:1,restitution:.8});let w2=new World({gravity:new Vec3(0,0,0)});w2.add(floor);w2.add(ball);w2.step(1/60);assert(ball.velocity.y>=0,'sphere-box contact should bounce upward');
let w3=new World({gravity:new Vec3(0,-9.81,0)}),falling=w3.add(new Body({y:2,mass:1}));w3.step(1/60);assert(falling.position.y<2,'gravity should integrate position');
console.log('PASS: sphere-sphere, sphere-box impulse, fixed-step gravity');
