const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync(__dirname+'/app/src/main/assets/engine3d_runtime.js','utf8');
let nextId=1,raf=new Map();
const root={classList:{contains:n=>n==='active'}};
const canvas={isConnected:true,dataset:{},closest:()=>root};
class MutationObserver{constructor(cb){this.cb=cb}observe(){}disconnect(){}}
const listeners={};const document={hidden:false,addEventListener:(n,f)=>(listeners['d'+n]=f),removeEventListener(){},dispatchEvent(){}};
const window={addEventListener:(n,f)=>(listeners['w'+n]=f),removeEventListener(){}};
const ctx={window,document,MutationObserver,requestAnimationFrame:fn=>{const id=nextId++;raf.set(id,fn);return id},cancelAnimationFrame:id=>raf.delete(id),console,Event:function(n){this.type=n}};
vm.createContext(ctx);vm.runInContext(code,ctx);
let draws=0;const scene=ctx.window.Koto3DRuntime.register('test',canvas,()=>draws++);
assert.equal(scene.active,true);assert.equal(raf.size,1,'scene should schedule a frame');
ctx.window.Koto3DRuntime.pauseAll();assert.equal(ctx.window.Koto3DRuntime.isPaused(),true);assert.equal(raf.size,0,'pauseAll must cancel frames');
ctx.window.Koto3DRuntime.resumeAll();assert.equal(scene.active,true);assert.equal(raf.size,1,'resumeAll must restart active scenes');
const callback=[...raf.values()][0];raf.clear();callback(100);assert.equal(draws,1,'frame callback should draw');
scene.dispose();assert.equal(ctx.window.Koto3DRuntime.getStats().length,0);assert.equal(raf.size,0);
console.log('Runtime tests passed: registration, pause/resume, frame rendering and disposal.');
