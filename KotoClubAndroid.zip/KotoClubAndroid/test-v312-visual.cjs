const fs=require('fs');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const checks=[
 ['versioned visual layer',html.includes('id="koto-v312-polish"')],
 ['reduced motion support',html.includes('prefers-reduced-motion:reduce')],
 ['match-3 depth styling',html.includes('#matchBoard .match-tile')],
 ['memory depth styling',html.includes('#memGrid button')],
 ['fishing scene polish',html.includes('#fishing #fishPond')],
 ['page lifecycle hooks',html.includes('id="koto-v312-lifecycle"')],
 ['3D runtime pause/resume',html.includes('Koto3DRuntime.pauseAll()')&&html.includes('Koto3DRuntime.resumeAll()')],
];
for(const [name,ok] of checks){if(!ok){console.error('FAIL:',name);process.exitCode=1}else console.log('PASS:',name)}
