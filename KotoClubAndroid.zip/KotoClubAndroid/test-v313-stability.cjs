const fs=require('fs');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/index.html','utf8');
const checks=[
 ['difficulty setter validates game IDs',html.includes("const allowed=new Set(['merge','wordle','cube'")],
 ['difficulty setter does not navigate screens',!html.slice(html.indexOf('function setGameLevel('),html.indexOf('function syncGameLevels')).includes('openGame(')],
 ['difficulty controls stay above scene layers',html.includes('.level-panel{position:relative;z-index:8')],
 ['gold run has wider obstacle spacing',html.includes('if(carTick%8===1)')&&html.includes("type:Math.random()<.36?'coin':'block',z:12")],
 ['gold run perspective uses 12-step depth',html.includes('1-(o.z||0)/12')],
 ['Koto-1024 tiles animate position/press changes',html.includes('#mergeGrid .merge-cell{')&&html.includes('cubic-bezier(.2,.8,.2,1)')],
 ['reduced-motion disables tile transition',html.includes('@media(prefers-reduced-motion:reduce){#mergeGrid .merge-cell{transition:none!important')],
 ['platformer DOM obstacle animation no longer fights JS positioning',html.includes('#platformer #platObstacle{animation:obstacle-bob .9s ease-in-out infinite alternate!important}')],
];
for(const [name,ok] of checks){if(!ok){console.error('FAIL:',name);process.exitCode=1}else console.log('PASS:',name)}
